/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'ko', {
	title: 'TeX 문법 수식',
	button: '수식',
	dialogInput: '여기 TeX 를 입력하세요',
	docUrl: 'http://ko.wikipedia.org/wiki/%EC%9C%84%ED%82%A4%EB%B0%B1%EA%B3%BC:TeX_%EB%AC%B8%EB%B2%95',
	docLabel: 'TeX 문서',
	loading: '불러오는 중...',
	pathName: '수식'
} );
